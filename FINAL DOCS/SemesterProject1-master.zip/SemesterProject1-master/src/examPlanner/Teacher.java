package examPlanner;

public class Teacher extends Person
{
  public Teacher(Integer id, String firstName, String lastName, String subjects)
  {
    super(id, firstName, lastName, subjects);
  }
}
