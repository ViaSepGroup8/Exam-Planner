package examPlanner;

public class Student extends Person
{
  public Student(Integer id, String firstName, String lastName, String subjects)
  {
    super(id, firstName, lastName, subjects);
  }
}
